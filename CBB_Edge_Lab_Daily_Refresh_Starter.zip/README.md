# CBB Edge Lab: daily-refresh website starter

**Status:** Website prototype plus scheduled refresh code. Not deployed. Not a complete automated efficiency-rating model.

## Deploy
1. Create a GitHub repository and upload all files including `.github/workflows/morning-refresh.yml`.
2. Enable GitHub Actions workflow permissions to read and write repository contents.
3. Enable GitHub Pages (Deploy from branch, main, root) or connect the repository to a static hosting service.
4. Run the `CBB Edge Lab morning refresh` workflow manually once to test it.
5. Check the workflow log, the `data/daily.json` updated timestamp, and the Today tab. A live URL is only available after hosting is configured.

## Automation
GitHub Actions attempts a refresh daily at **8:00 AM America/Chicago** (both daylight and standard time). Scheduled workflows can be delayed or paused by GitHub; no uptime guarantee. The workflow uses the unofficial public NCAA API wrapper documented at https://github.com/henrygd/ncaa-api . This provider has rate limits and may change or fail. A failed refresh preserves the last successful JSON and logs an error. This refresh updates **schedule and scores only**, not adjusted offensive/defensive ratings, injury reports, betting odds, or pace.

## Ratings and licensing
The current site retains 191 provisional team ratings from the previous workbook. Do not claim daily-updated ratings or complete Division I coverage. A separate permitted source or independently calculated model is required before rating updates can be automated. Confirm licensing before publishing or redistributing any third-party data.

## Operations
For production, add source monitoring, team-name normalization, nightly game ingestion, deduplication, rating calculation, coverage checks, stale-data alerts, and explicit model versioning. Never silently replace a missing rating with a made-up number.
